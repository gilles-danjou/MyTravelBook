module.exports = {
	'port': process.env.PORT || 8080,
	// 'database': 'mongodb://node:noder@novus.modulusmongo.net:27017/Iganiq8o',
    'database': 'mongodb://localhost:27017/mytravelbook',
	'secret': 'ilovescotchscotchyscotchscotch'
};